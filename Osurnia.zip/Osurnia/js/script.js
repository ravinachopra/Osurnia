$(document).ready(function() {
			 // caluculate height for dog image for mobile 
			 var heightValue=0;
			 heightCalculator();
			
			function heightCalculator(){
				 heightValue=$('.gel-section .features').height();
				$('.dog-image-container img').css('height',heightValue);				
			}

			// add more occurneces
			$('.add-more-occurences').click(function(){
				  $(".dropdown-list:first-child").clone().appendTo(".dropdown-container:first");
				});

			//scroll on click of navigation menu links
			$('.nav-link-wrapper a').click(function () {
				$('html, body').animate({
					scrollTop: $($(this).attr('href')).offset().top
				}, 500);
				return false;
			});

			//change of checkbox iamge on click
			$('.chkbox-container span,.chkbox-container p').click(function(){
				$(this).parent().toggleClass('optionSelected');	
				if($(this).parent().hasClass('optionSelected')){
					$(this).parent().find('img').attr('src','img/chk-chkbox.png');		
				}
				else{
					$(this).parent().find('img').attr('src','img/chkbox.png');			
				}
				
			});

			//summary generation
			$('.submit-container span').click(function(){
				$('.overlay').show();
				var symptomString="",seasonString="",dateString="";			
				$('.dropdown-list').each(function(i, obj) {
					//var month=$(obj).find('.month-list').val();
					var month="",day="",year="";

					if($(obj).find('.month-list').val()){
						 month=$(obj).find('.month-list').val();
					}
					if($(obj).find('.day-list').val()){
						 day=$(obj).find('.day-list').val();
					}
					if($(obj).find('.year-list').val()){
						 year=$(obj).find('.year-list').val();
					}
					/*var day=$(obj).find('.day-list').val();
					var year=$(obj).find('.year-list').val();*/
					var suffix="", dateArray=[];
					switch(parseInt(day)) {
						case 1:
						case 21:
						case 31:
							suffix="st";
							break;
						case 2:
						case 22:
							suffix="nd";
							break;
						case 3:
						case 23:
							suffix="rd";
							break;
						default:
							suffix="th";
					}
					if(day==""){
						suffix="";
					}
					if(month!="" && day!="" && year!=""){
						dateString= dateString+month+' '+ day + suffix+','+' '+year +', ';							
					}					
					else{
						dateString=dateString;
					}
					
					//dateArray.push(dateString);	
					
					
				});
				var noOfEarInfections= $('.infection-number select').val();				
				$('.signs-select-list .optionSelected').each(function(i, obj) {
					var symptom=$(obj).find('p').text();
					//symptomArray.push(symptom);
					if(symptom!=""){
						symptomString=symptomString + symptom +', ';	
					}
					else{
						symptomString=symptomString;
					}				
					
				
				});
				$('.seasons-select-list .optionSelected').each(function(i, obj) {
					var season=$(obj).find('p').text();
					//seasonArray.push(season);
					
					if(season!=""){
						seasonString=seasonString+ season +', ';
					}

					else{
						seasonString=seasonString;
					}
				
				});
				 dateString = dateString.substr(0, dateString.length-2);

				if(symptomString==""){
						symptomString="";
				}
				else if(symptomString.lastIndexOf(',')== symptomString.indexOf(',')){
					symptomString=symptomString.substr(0, symptomString.length-2);
				}
				else{
					symptomString=symptomString.substr(0, symptomString.length-2);
				 symptomString = symptomString.slice( 0, symptomString.lastIndexOf( "," ) ) + " and"  + symptomString.substring( symptomString.lastIndexOf( "," )+1 );
				}
				if(seasonString==""){
						seasonString="";
				}
				else if(seasonString.lastIndexOf(',')== seasonString.indexOf(',')){
					seasonString=seasonString.substr(0, seasonString.length-2);
				}
				else{

					 seasonString=seasonString.substr(0, seasonString.length-2);
				 seasonString = seasonString.slice( 0, seasonString.lastIndexOf( "," ) ) + " and"  + seasonString.substring( seasonString.lastIndexOf( "," )+1 );
				}


				 
				
				$('.summary-form').hide();
				

				$('.sum-dates').text('').text(dateString);
				$('.sum-symptoms').text('').text(symptomString);
				$('.sum-infections').text('').text(noOfEarInfections);
				$('.sum-seasons').text('').text(seasonString);
				$('.form-summary').show();
				$(window).scrollTop($('.form-summary').offset().top);
				
				

			});
		  
        });
		
		
		